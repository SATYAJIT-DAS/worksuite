<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Subdomain\\Providers\\SubdomainServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Subdomain\\Providers\\SubdomainServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);