<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Asset\\Providers\\AssetServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Asset\\Providers\\AssetServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);