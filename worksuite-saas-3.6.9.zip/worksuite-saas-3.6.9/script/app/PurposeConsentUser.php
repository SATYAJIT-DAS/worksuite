<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PurposeConsentUser extends BaseModel
{
    protected $table = 'purpose_consent_users';


}
